# -*- coding: utf-8 -*-
"""
Created on Fri Nov 24 15:02:25 2017

@author: Everyheart
"""

import tushare as ts
import matplotlib.pyplot as plt
import pandas as pd 
cons = ts.get_apis()
df = ts.bar('204001', conn=cons, freq='D', start_date='2016-01-01', end_date='')
df = ts.bar('204001', conn=cons, start_date='2016-01-01', end_date='', ma=[5, 10, 20], factors=['vr', 'tor'])
df = ts.bar('204001', conn=cons, freq='1min', start_date='2016-01-01', end_date='')
df = ts.tick('204001', conn=cons, date='2017-10-26')

shibor=ts.shibor_data(year=2016)
plt.plot(shibor["1W"])
#shibor利率
shibor=ts.shibor_data()
#%%
#首先需要将交易数据中因为交易日及假期的因素剔除
#（1）因为我们要处理的是K线的数据，这里选择30分钟级别的数据
import tushare as ts
import matplotlib.pyplot as plt
import pandas as pd 
import tushare as ts
cons = ts.get_apis()
stock='204007'
df = ts.bar(stock, conn=cons, freq='30min', start_date='2017-05-22', end_date='')
df=df.sort_index(axis=0,ascending=True)

#定义一个函数剔除交易日的因素
d=int(stock[-2:])#获得期限
def tc0(df):#获得了这里的时间的差，但是这里只考虑了自然日，没有考虑交易日
    m=int(len(df)/8-1)
    delta0=list()
    for i in range(m):
        s=8*(i+1)-1
        t=8*(i+2)-1
        delta=(df.index[t]-df.index[s]).days
        delta0.append(delta)
    return delta0
delta=tc0(df)#len(a)是有多少个交易日-1，sun(a)是一共的天数，具体的看开始的日期
#=============================================
#根据最新得到的信息，定义出准确的国债逆回够的
def tc3(df,d,delta):
    TR=[]
    BL=[]
    for i in range(len(delta)):
        qh=1
        qq=delta[i]
        try: 
            for s in range(1,d-1):
                qh=qh+delta[i+s]
                if qh>=d:
                    break
                else:
                    continue
            qqq=qq+qh-1
            bili=qh/qqq
            TR.append(qh)
            BL.append(bili)
        except:
            break
    return TR,BL
v,vv=tc3(df,d,delta)    
len(vv)
    

df2=df.iloc[:len(vv)*8,:]#这里需要删除最后几个，保留len(TR)*8个数据
#首先构造一个8*TR的list
a=[]
for i in range(len(vv)):
    for s in range(8):
        a.append(vv[i])
df2["code"]=a




df2["open"]=(df2["code"]*df2["open"]).values
df2["close"]=(df2["code"]*df2["close"]).values
df2["high"]=(df2["code"]*df2["high"]).values    
df2["low"]=(df2["code"]*df2["low"]).values    

#这里已经获得了我们想要的结果，也就是数据    

#plt.plot(df2["high"])
#plt.plot(df2["low"])


#剔除收盘前的影响：
T=[]
for i in range(int(len(df2)/8)):
    t=8*(i+1)-1
    T.append(t)
df3=df2.drop(df2.index[T])
plt.figure()
plt.plot(df3["close"])
plt.title(stock)
df3['close'].mean()
GC007=df3["close"][:854]
GC007.describe()
#%%这里考虑定义个函数能筛选出每个月最后几n个交易日的数据，方便分析
#这里的思路就是删除每个月除了这些数据前的数据，我们也就需要构建一个删除数据的List

a=list(df3.index)
b=[]
c=[]
for i in range(len(a)):
    weekday=a[i].weekday()
    b.append(weekday)
for i in range(len(a)):
    month=a[i].month
    c.append(month)
liu=[]
for i in range(len(c)-1):
    if c[i]!=c[i+1]:
        cc=[]
        for s in range(3):
            cc.append(i-21+1+s)
        liu.extend(cc)
    else:
        continue
df4=df3.iloc[liu]
df4["close"].describe()
#%%
def yuemoshuju(df3,day=4,lx=1) :
    """这里的一个参数是之前的数表，第二个是月初或者月末几天，lx=1就是月末，lx=0就是月初"""
    a=list(df3.index)
    c=[]
    liu=[]
    for i in range(len(a)):
        month=a[i].month
        c.append(month)
    for i in range(len(c)-1):
        if c[i]!=c[i+1]:
            cc=[]
            if lx==1:
                for s in range(7*day):
                    cc.append(i-7*day+1+s)
                liu.extend(cc)
            else: 
                for s in range(7*day):
                    if i+1+s<=len(c)-1:  
                        cc.append(i+1+s)
                    else:
                        break
                liu.extend(cc)
        else:
            continue 
    df4=df3.iloc[liu]
    df4["close"].describe()
    return df4
df4=yuemoshuju(df3,5,0)
#%%
mean1=[]      
for i in range(25):
    df4=yuemoshuju(df3,i,0)
    mean0=df4['close'].mean()
    mean1.append(mean0)
plt.figure
plt.title("GC007")
plt.plot(mean1)
plt.ylabel("rate")
plt.xlabel("days")
mean1=[] 
#%%
mean1=[] 
for i in range(25):
    df4=yuemoshuju(df3,i,1)
    mean0=df4['close'].mean()
    mean1.append(mean0)
plt.figure
plt.title("GC007")
plt.plot(mean1)
plt.ylabel("rate")
plt.xlabel("days")
df4["close"].describe() 
#%%
stats.norm.ppf(0.8,df4["close"].mean(),df4["close"].std())
#%%数据的简单的分析|
#（1）对于数据简单的统计性质：
df3["close"].describe()
#%%
df3["high"].describe()
#%%
plt.figure()
df3["high"].hist(bins=100,range=[0,10])
#%%
#(2)
from statsmodels.tsa import stattools
acfs=stattools.acf(df3["close"])
pacfs=stattools.pacf(df3["close"])
from statsmodels.graphics.tsaplots import *
plot_pacf((df3["close"]),use_vlines=True,lags=40)
#%%
from arch.unitroot import ADF
adf1=ADF(df3["close"])
print(adf1)#平稳性检验，说明序列平稳
from statsmodels.tsa import stattools
L=stattools.q_stat(stattools.acf(df3["close"])[1:12],len(df3["close"]))
L[1]#结果显示不是白噪声序列
#%%
#构建ARMA模型
close=df3["close"]
from statsmodels.graphics.tsaplots import *
axe1=plt.subplot(121)
axe2=plt.subplot(122)
plot1=plot_acf(close,ax=axe1)
plot2=plot_pacf(close,ax=axe2)
#明显拖尾
#%%
from statsmodels.tsa import arima_model
model1=arima_model.ARIMA(close,order=(1,0,1)).fit()
model1.summary()
model2=arima_model.ARIMA(close,order=(1,0,2)).fit()
model2.summary()
model3=arima_model.ARIMA(close,order=(2,0,1)).fit()
model3.summary()
#%%
stattools.arma_order_select_ic(close,max_ma=4)
#%%
model4=arima_model.ARIMA(close,order=(1,0,0)).fit()
model4.summary()#最低  AIC  1319.124)
#%%
import math
model4.conf_int()
stdresid=model4.resid/math.sqrt(model4.sigma2)
plt.plot(stdresid)
plot_acf(stdresid,lags=20)
plot_pacf(stdresid,lags=20)
from statsmodels.tsa import stattools
L=stattools.q_stat(stattools.acf(stdresid)[1:13],len(stdresid))
L[1][-1]
#%%
v=model4.forecast(4)[0]#ARMA模型对未来进行预测

#%%ARCH模型
from arch import arch_model
am=arch_model(close)
model=am.fit(update_freq=0)
model.summary()

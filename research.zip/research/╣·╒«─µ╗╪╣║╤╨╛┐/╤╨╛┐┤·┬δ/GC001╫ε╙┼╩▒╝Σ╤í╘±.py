# -*- coding: utf-8 -*-
"""
Created on Mon Nov 27 17:22:06 2017

@author: Everyheart
"""

import tushare as ts
import matplotlib.pyplot as plt
import pandas as pd 
#%%
cons = ts.get_apis()
stock='204001'
df = ts.bar(stock, conn=cons, freq='1min', start_date='2017-07-12', end_date='2017-12-04')
df=df.sort_index(axis=0,ascending=True)#这里的df包含了所有的1分钟的数据
#%%
#定义一个函数剔除交易日的因素，这里只要把240换成16,8这些每天时间周期的个数就可以了。
kk=240
d=int(stock[-2:])#获得期限
def tc0(df):#获得了这里的时间的差，但是这里只考虑了自然日，没有考虑交易日
    m=int(len(df)/kk-1)
    delta0=list()
    for i in range(m):
        s=kk*(i+1)-1
        t=kk*(i+2)-1
        delta=(df.index[t]-df.index[s]).days
        delta0.append(delta)
    return delta0
delta=tc0(df)#len(a)是有多少个交易日-1，sun(a)是一共的天数，具体的看开始的日期
#根据最新得到的信息，定义出准确的国债逆回够的
def tc3(df,d,delta):
    TR=[]
    BL=[]
    for i in range(len(delta)):
        qh=1
        qq=delta[i]
        try: 
            for s in range(1,d-1):
                qh=qh+delta[i+s]
                if qh>=d:
                    break
                else:
                    continue
            qqq=qq+qh-1
            bili=qh/qqq
            TR.append(qh)
            BL.append(bili)
        except:
            break
    return TR,BL
v,vv=tc3(df,d,delta)    
len(vv)


df2=df.iloc[:len(vv)*kk,:]#这里需要删除最后几个，保留len(TR)*8个数据
#首先构造一个8*TR的list
a=[]
for i in range(len(vv)):
    for s in range(kk):
        a.append(vv[i])
df2["code"]=a
df2["open"]=(df2["code"]*df2["open"]).values
df2["close"]=(df2["code"]*df2["close"]).values
df2["high"]=(df2["code"]*df2["high"]).values    
df2["low"]=(df2["code"]*df2["low"]).values   


#%%
#通过这个函数，生成一个数据的序列，以及计算出这个一分钟的均值，然后判断其是否有稳定性。

def averageshoupan(df,hour,minutes):
    n=len(df)
    Q=[]
    for i in range(n):
        if df.index[i].hour==hour and df.index[i].minute==minutes:
            q=i
        else:
            continue
        Q.append(q)
    df1=df.iloc[Q]
    mean0=df1['close'].mean()
    c=df1['close'].std()
    return df1,mean0,c
a,b,c=averageshoupan(df2,15,0)
aa=a['close']
plt.plot(aa)
print(b)
#%%
#做adf检验
from arch.unitroot import ADF
aaa=ADF(aa)
#%%
TIME=[]
#为了统计全天的均值，我们首先就是构建一个list，得到时间的序列，包括9:31-9:59,10:00-10:59,11:00-11:29,13：00-13:59,14:00-14:59
for i in range(31,60):
    j=9
    TIME.append([j,i])
for i in range(0,60):
    j=10
    TIME.append([j,i])
for i in range(0,30):
    j=11
    TIME.append([j,i])
for j in[13,14]:
    for i in range(0,60):
        TIME.append([j,i])
TIME.append([15,0])
print(TIME)    
    
#%%
JUNZHI=[]
P=[]
STD=[]
#for i in range(0,60,1):
for i,j in TIME:    
    a0,junzhi,std=averageshoupan(df2,i,j)
    aa0=a0['close']
    p=ADF(aa0)
    p=p.pvalue
    JUNZHI.append(junzhi)
    P.append(p)
    STD.append(std)
    
    
    
    
    
#%%
plt.figure()
plt.plot(JUNZHI)
plt.title("mean")
plt.xlabel("time")
plt.ylabel("rate")
plt.xlim(0,240)
#plt.grid(axis="both")

plt.figure()
plt.plot(P)
plt.title("Pvalue")
plt.xlabel("time")
plt.ylabel("pvalue")
plt.xlim(0,240)

plt.figure()
plt.plot(STD)
plt.title("std")
plt.xlabel("time")
plt.ylabel("std")
plt.xlim(0,240)
#%%
plt.figure()
ax1=plt.subplot(311)
ax2=plt.subplot(312)
ax3=plt.subplot(313)
ax1.plot(JUNZHI)
ax2.plot(P)
ax3.plot(STD)










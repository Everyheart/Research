# -*- coding: utf-8 -*-
"""
Created on Tue Dec  5 20:32:01 2017
GC001数据统计0.012
注意这里的第三个部分不用运行，这里不需要剔除假期因素
@author: Everyheart
"""

import tushare as ts
import matplotlib.pyplot as plt
import pandas as pd 
import numpy as np
#%%
cons = ts.get_apis()
stock='204001'
df = ts.bar(stock, conn=cons, freq='5min', start_date='2016-01-01', end_date='2017-12-01')
df=df.sort_index(axis=0,ascending=True)


dff=ts.bar(stock, conn=cons, freq='D', start_date='2016-01-01', end_date='2017-12-01')
dff=dff.sort_index(axis=0,ascending=True)
dfsz=ts.bar('000001', conn=cons, freq='5min', start_date='2016-01-01', end_date='2017-12-01',asset='INDEX')
dfsz=dfsz.sort_index(axis=0,ascending=True)
dfszz=ts.bar('399001', conn=cons, freq='5min', start_date='2016-01-01', end_date='2017-12-01',asset='INDEX')
dfszz=dfszz.sort_index(axis=0,ascending=True)
#%%
#因为涨跌幅判断的时候加入交易日因素就会导致数据错误判断。也就是虽然早盘大涨，但是却不能反映，因为这里也会导致df数据的改变，因此这里直接剔除

#定义一个函数剔除交易日的因素
d=int(stock[-2:])#获得期限
kk=48
def tc0(df):#获得了这里的时间的差，但是这里只考虑了自然日，没有考虑交易日
    m=int(len(df)/kk-1)
    delta0=list()
    for i in range(m):
        s=kk*(i+1)-1
        t=kk*(i+2)-1
        delta=(df.index[t]-df.index[s]).days
        delta0.append(delta)
    return delta0
delta=tc0(df)#len(a)是有多少个交易日-1，sun(a)是一共的天数，具体的看开始的日期
#根据最新得到的信息，定义出准确的国债逆回够的
def tc3(df,d,delta):
    TR=[]
    BL=[]
    for i in range(len(delta)):
        qh=1
        qq=delta[i]
        try: 
            for s in range(1,d-1):
                qh=qh+delta[i+s]
                if qh>=d:
                    break
                else:
                    continue
            qqq=qq+qh-1
            bili=qh/qqq
            TR.append(qh)
            BL.append(bili)
        except:
            break
    return TR,BL
v,vv=tc3(df,d,delta)    
len(vv)


df2=df.iloc[:len(vv)*kk,:]#这里需要删除最后几个，保留len(TR)*8个数据
#首先构造一个8*TR的list
a=[]
for i in range(len(vv)):
    for s in range(kk):
        a.append(vv[i])

df2["code"]=a
df2["open"]=(df2["code"]*df2["open"]).values
df2["close"]=(df2["code"]*df2["close"]).values
df2["high"]=(df2["code"]*df2["high"]).values    
df2["low"]=(df2["code"]*df2["low"]).values  

df2['morning0']=np.zeros([len(df2),1])
df2['morning1']=np.zeros([len(df2),1])
df2['afternoon0']=np.zeros([len(df2),1])
df2['afternoon1']=np.zeros([len(df2),1])

#%%

#函数构成第一部分：时间截取，选择最近的n天的数据（2017-01-03  到2017-12-01）
def timechoose(df,dff,dfsz,dfszz,n):
    df1=df[-48*n:]
    df2=dff.iloc[-n:,:1]
    df3=dff.iloc[-n:,:]
    dfsz=dfsz.iloc[-48*n:]
    dfszz=dfszz.iloc[-48*n:]
    return df1,df2,df3,dfsz,dfszz
df3,df4,df5,dfsz,dfszz=timechoose(df,dff,dfsz,dfszz,224)
shibor=ts.shibor_data()
shibor=shibor[:224]
#%%

#数据计算并且叠加进入这个数据中

def dealdf(df,dff,dfff,dfsz,dfszz,lx):#这里的df是时间截取后的
    m=int(len(df)/48)
    M=[]
    
    #第一个计算出上午的最高涨幅
    for i in range(m):
        dff.ix[i,'day']=dff.index[i].day
        #上午的各个时间点的回报=========================================================
        maxprice0=max(df.ix[48*i:48*i+24,"high"])
        M.append(maxprice0)
        if i==0:
            morzf=100*(maxprice0-df.ix[0,"close"])/df.ix[0,"close"]
        else:
            morzf=100*(maxprice0-df.ix[48*i-1,"close"])/df.ix[48*i-1,"close"]
        dff.ix[i,"mormax"]=morzf
        #对于9:30到11:00各个时间段的回报做统计
        time1000=df.ix[48*i+6-1,"close"]
        time1030=df.ix[48*i+12-1,"close"]
        time1100=df.ix[48*i+18-1,"close"]
        time1130=df.ix[48*i+24-1,'close']
        dff.ix[i,'amount']=df.ix[48*i+12-1,"amount"]
        if i==0:
            startprice1=df.ix[0,"close"]
        else:
            startprice1=df.ix[48*i-1,"close"]
        hb1000=(time1000-startprice1)*100/startprice1
        hb1030=(time1030-startprice1)*100/startprice1
        hb1100=(time1100-startprice1)*100/startprice1
        hb1130=(time1130-startprice1)*100/startprice1
        dff.ix[i,'hb1000']=hb1000#各个时间点的收盘回报
        dff.ix[i,'hb1030']=hb1030
        dff.ix[i,'hb1100']=hb1100
        dff.ix[i,'hb1130']=hb1130
     
    #dff["mormaxq"]=pd.qcut(dff["mormax"],9)#划分为区间,划分为9个区间
   # dff["hb1000q"]=pd.qcut(dff["hb1000"],9)#划分为区间
   # dff["hb1030q"]=pd.qcut(dff["hb1030"],9)
   # dff["hb1100q"]=pd.qcut(dff["hb1100"],9)
   # dff["hb1130q"]=pd.qcut(dff["hb1130"],9)
    #下午的核心时间点收益======================================================
    for i in range(m):
        startprice0=df.ix[48*i+23,"close"]
        time1330=df.ix[48*i+30-1,"close"]
        time1400=df.ix[48*i+36-1,"close"]
        time1430=df.ix[48*i+42-1,"close"]
        time1445=df.ix[48*i+45-1,"close"]
        meanxw=(time1330+time1400+time1430+time1445)/4
        xwmean=(meanxw-startprice0)*100/startprice0
        hb1330=(time1330-startprice0)*100/startprice0
        hb1400=(time1400-startprice0)*100/startprice0
        hb1430=(time1430-startprice0)*100/startprice0
        hb1445=(time1445-startprice0)*100/startprice0
       # dff.ix[i,"xwmean"]=xwmean
       # dff.ix[i,"hb1330"]=hb1330
       # dff.ix[i,"hb1400"]=hb1400
       # dff.ix[i,"hb1430"]=hb1430
       # dff.ix[i,"hb1445"]=hb1445
    #这个部分是计算距离月末的时间点。==========================================
    a=list(dff.index)
    c=[]
    for i in range(len(a)):
        month=a[i].month
        c.append(month)
    dff['month']=c
        
    
    bb=dff['month'].values
    d=list(np.zeros(len(bb)))
    b=range(len(bb))
    q=0
    for i in range(len(bb)-1):
        if bb[i]!=bb[i+1]:
            print(i)
            for s in range(q,i+1):
                d[s]=b[i+1]-b[s]
            q=i+1
        else:
            continue
    dff['yuemo']=d
    #======================================================================
    if lx==1:#类型为1表示的是我们采用上午最大值和下午最小值作为波动幅度来处理这个实际上就是振幅，这里的缺点是没有用上午的最高点和下午的最低点
        for i in range(m):
            dff.ix[i,'zhenfu']=(dfff.ix[i,'high']-dfff.ix[i,'low'])/dfff.ix[i,'high']
        dff["zhenfuq"]=pd.qcut(dff["zhenfu"],3)
    elif lx==2: #类型2表示的是以上午的均值和下午的均值的波动幅度
        #这里我们严格计算所有的值

        for i in range(m):
            a=0
            if i==0:
                startprice1=df.ix[0,"close"]
            else:
                startprice1=df.ix[48*i-1,"close"]
            for s in range(24):
                a=a+df.ix[48*i+s,'close']
            mean=a/24
            dff.ix[i,'mormean']=mean
            dff.ix[i,'mormeanz']=(mean-startprice1)

            b=0
            for s in range(23):
                b=b+df.ix[48*i+24+s,'close']
            mean1=b/23
            dff.ix[i,'aftmean']=mean1
            
            dff.ix[i,'moraft']=(mean1-mean)#从上午到下午的变化
            dff.ix[i,'daymean']=(mean+mean1)/2
    elif lx==3:#类型三是shibor有关的计算
        for i in range(m):
            for s in range(len(shibor)):
                if shibor['date'][s].month==dff.index[i].month and shibor['date'][s].day==dff.index[i].day:
                    dff.ix[i,'shibor']=shibor['ON'][s]
                else:
                    continue
            if i==0:
                dff.ix[i,'shiborbd']=0
            else:
                dff.ix[i,'shiborbd']=(dff['shibor'][i]-dff['shibor'][i-1])*100/dff['shibor'][i-1]
    elif lx==4:#类型4是将类型2中的下午的均值换成下午某个时间段的均值
        for i in range(m):
            a=0
            if i==0:
                startprice1=df.ix[0,"close"]
            else:
                startprice1=df.ix[48*i-1,"close"]
            for s in range(24):
                a=a+df.ix[48*i+s,'close']
            mean=a/24#上午的均值
            dff.ix[i,'mormean']=mean
            dff.ix[i,'mormeanzf']=(mean-startprice1)/startprice1

            b=0#这里我们选择时间为14:20-14:40
            for s in range(4):
                b=b+df.ix[48*i+40+s,'close']
            mean1=b/4
            dff.ix[i,'20-40mean']=mean1
            for s in range(23):
                b=b+df.ix[48*i+24+s,'close']
            mean11=b/23
            dff.ix[i,'mean1']=mean11  #这个用来计算全天的均值来用的          
            dff.ix[i,'moraft']=(mean1-mean)#从上午到下午的变化
            dff.ix[i,'daymean']=(mean+mean11)/2
            dff.ix[i,'xw-20-40cha']=mean1-mean11#两个均值差
        
    for i in range(m):
        startprice1=dfsz.ix[48*i,'open']
        zs1000=dfsz.ix[48*i+6-1,"close"]
        zs1030=dfsz.ix[48*i+12-1,"close"]
        zs1100=dfsz.ix[48*i+18-1,"close"]
        zs1130=dfsz.ix[48*i+24-1,'close']       
        #上证涨幅
        amount0=0
        for s in range(12):
            amount0=amount0+dfsz.ix[48*i+s,'amount']
        dff.ix[i,'amount1030']=amount0#10:30的这个成交量，这里10:30对应s的range（12）,11:30对应range（24）,上证对应于dfsz,深圳改为dfszz
        dff.ix[i,'szzf1030']=(zs1030-startprice1)/startprice1
        dff.ix[i,'szzf1130']=(zs1130-startprice1)/startprice1
    return dff,bb









a,bb=dealdf(df3,df4,df5,dfsz,dfszz,4)
#%%
#这个是成交量和波动的关系
plt.figure()
plt.plot(a['amount1030'],a['moraft'],'.')
#plt.plot(a['yuemo'],a['moraft'],'.')
plt.grid()
plt.title("amount1030-bodong")
plt.xlabel('amount')
plt.ylabel('bodong')
#%%
#这个是上证指数的涨幅和波动的关系

plt.figure()
plt.plot(a['szzf1130'],a['moraft'],'.')

plt.grid()
plt.title("zf1130-bodong")
plt.xlabel('zf')
plt.ylabel('bodong')
#%%
#日期和均值
plt.figure()
plt.plot(a['day'],a['moraft'],'.')
#plt.plot(a['yuemo'],a['moraft'],'.')
plt.grid()
plt.title("day-bodong")
plt.xlabel('day')
plt.ylabel('bodong')
#%%
#上午涨幅均值-波动
plt.figure()
plt.plot(a['mormeanzf'],a['moraft'],'.')
#plt.plot(a['yuemo'],a['moraft'],'.')
plt.grid()
plt.title("morzf-bodong")
plt.xlabel('morzf')
plt.ylabel('bodong')



#%%
#画出shibor变动和早上涨跌的关系
plt.figure()
plt.plot(a['shiborbd'],a['hb1030'],'.')
#plt.plot(a['yuemo'],a['moraft'],'.')
plt.grid()
a['moraft'].mean()
#%%
#成交量-波动
plt.figure()
plt.plot(a['amount1030'],a['moraft'],'.')
#plt.plot(a['yuemo'],a['moraft'],'.')
plt.grid()
plt.title("amount1030-bodong")

#print(a[["moraft",'hb1030']].groupby(["hb1030"],as_index=False).mean())

#mean22=(a[["moraft",'hb1030']].groupby(["hb1030"],as_index=False).mean())['moraft'].values
#std22=(a[["moraft",'hb1030']].groupby(["hb1030"],as_index=False).std())['moraft'].values
#plt.plot(list(range(0,len(mean22))),mean22)
#plt.plot(list(range(0,len(mean22))),std22)



#print(a)
#%%
print(a[["xwmean","hb1330","hb1400","hb1430","hb1445",'yuemo']].groupby(["yuemo"],as_index=False).mean())
#%%
#月末日期-波动的关系
plt.figure()
plt.plot(a['yuemo'],a['moraft'],'.')
#plt.plot(a['yuemo'],a['moraft'],'.')
plt.title('yuemo-bodong')
plt.xlabel('yuemo')
plt.ylabel('bodong')
plt.grid()
a['moraft'].mean()

print(a[["moraft",'yuemo']].groupby(["yuemo"],as_index=False).mean())
mean22=(a[["moraft",'yuemo']].groupby(["yuemo"],as_index=False).mean())['moraft'].values
std22=(a[["moraft",'yuemo']].groupby(["yuemo"],as_index=False).std())['moraft'].values
plt.plot(list(range(0,24)),mean22)
plt.plot(list(range(0,24)),std22)
#%%
#日期-波动
plt.figure()
plt.plot(a['day'],a['moraft'],'.')
#plt.plot(a['yuemo'],a['moraft'],'.')
plt.title('day-bodong')
plt.xlabel('day')
plt.ylabel('bodong')
plt.grid()
a['moraft'].mean()
print(a[["moraft",'day']].groupby(["day"],as_index=False).mean())
mean22=(a[["moraft",'day']].groupby(["day"],as_index=False).mean())['moraft'].values
std22=(a[["moraft",'day']].groupby(["day"],as_index=False).std())['moraft'].values
plt.plot(list(range(1,32)),mean22)
plt.plot(list(range(1,32)),std22)
#%%
print(a[['hb1130q',"xwmean","hb1330","hb1400","hb1430","hb1445"]].groupby(['hb1130q'],as_index=False).mean())
#%%
mormax=[]
hb1445=[]
hb1400=[]
hb1330=[]
hb1430=[]
for i in range(len(df4)):
    mormax.append(a.ix[i,"mormax"])
    hb1445.append(a.ix[i,"hb1445"])
    hb1400.append(a.ix[i,'hb1400'])
    hb1430.append(a.ix[i,'hb1430'])
    hb1330.append(a.ix[i,'hb1330'])
ax1=plt.subplot(221)
ax2=plt.subplot(222)
ax3=plt.subplot(223)
ax4=plt.subplot(224)
ax1.plot(mormax,hb1330,'r.')
ax1.set_title('hb1330')
ax2.plot(mormax,hb1400,'r.')
ax2.set_title('hb1400')
ax3.plot(mormax,hb1430,'r.')
ax3.set_title('hb1430')
ax4.plot(mormax,hb1445,"r.")
ax4.set_title('hb1445')


#%%
#plt.figure()


def shujuxulie(a,s='yuemo'):#输入数据，选择所想要获得的分类的index，就可以获得其各种分类的引索，具体的位置用qq[i]就可以获得了（0-n)
    a1=pd.get_dummies(a[s])
    qq=[]
    for i in range(a1.shape[1]):
        aa=[]
        for s in range(a1.shape[0]):
            if a1.iloc[s,i]==1:
                aa.append(s)
            else:
                continue
        qq.append(aa)
    return qq
                
c=shujuxulie(a)

#这个是处理月末数据特别的处理，去掉第一个
c=c[1:]#这里在不处理月末的时候不用改
#
#在c中有十个分类，每一个都有一个序列，这个序列是这一组的数据所在的序列。
def fenleitu(i,a):
    cc=a.ix[c[i],'hb1430']#获得这个数据
   # plt.hist(cc.values)
    return cc
fenleitu(8,a)
#for i in range(len(a)):
    
plt.figure()

ax1=plt.subplot(331)
ax2=plt.subplot(332)
ax3=plt.subplot(333)
ax4=plt.subplot(334)
ax5=plt.subplot(335)
ax6=plt.subplot(336)
ax7=plt.subplot(337)
ax8=plt.subplot(338)
ax9=plt.subplot(339)
p='hb1445'

c1=(a.ix[c[0],p]).values
c2=(a.ix[c[1],p]).values
c3=(a.ix[c[2],p]).values
c4=(a.ix[c[3],p]).values
c5=(a.ix[c[4],p]).values
c6=(a.ix[c[5],p]).values
c7=(a.ix[c[6],p]).values
c8=(a.ix[c[7],p]).values
c9=(a.ix[c[8],p]).values
ax1.hist(c1,bins=80)
ax2.hist(c2,bins=80)
ax3.hist(c3,bins=80)
ax4.hist(c4,bins=80)
ax5.hist(c5,bins=80)
ax6.hist(c6,bins=80)
ax7.hist(c7,bins=80)
ax8.hist(c8,bins=80)
ax9.hist(c9,bins=80)
#
ax1.set_ylabel(p)
ax1.set_title('1')
ax2.set_title('2')
ax3.set_title('3')
ax4.set_title('4')
ax5.set_title('5')
ax6.set_title('6')
ax7.set_title('7')
ax8.set_title('8')
ax9.set_title('9')
#%%
ax1.set_title('(-56.104, -1.065] ')
ax1.set_ylabel(p)
ax2.set_title('(-1.065, 4.227]')
ax3.set_title(' (4.227, 9.002]')
ax4.set_title('(9.002, 11.484] ')
ax5.set_title('(11.484, 16.139] ')
ax6.set_title(' (16.139, 22.26]')
ax7.set_title('(22.26, 34.503] ')
ax8.set_title('(34.503, 89.441]')
ax9.set_title('(89.441, 429.846]')


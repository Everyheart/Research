# -*- coding: utf-8 -*-
"""
Created on Fri Nov 24 15:02:25 2017

@author: Everyheart
"""

import tushare as ts
import matplotlib.pyplot as plt
import pandas as pd 
cons = ts.get_apis()
df = ts.bar('204001', conn=cons, freq='D', start_date='2016-01-01', end_date='')
df = ts.bar('204001', conn=cons, start_date='2016-01-01', end_date='', ma=[5, 10, 20], factors=['vr', 'tor'])
df = ts.bar('204001', conn=cons, freq='1min', start_date='2016-01-01', end_date='')
df = ts.tick('204001', conn=cons, date='2017-10-26')


#shibor利率
shibor=ts.shibor_data()
#%%
#首先需要将交易数据中因为交易日及假期的因素剔除
#（1）因为我们要处理的是K线的数据，这里选择30分钟级别的数据
import tushare as ts
import matplotlib.pyplot as plt
import pandas as pd 
import tushare as ts
cons = ts.get_apis()
stock='204002'
df = ts.bar(stock, conn=cons, freq='30min', start_date='2016-01-01', end_date='')
df=df.sort_index(axis=0,ascending=True)

#定义一个函数剔除交易日的因素
d=int(stock[-2:])#获得期限
#这里的思路就是根据后一个交易与前一个交易的时间差距，确定当前交易日的实际的回报
def tc0(df):#获得了这里的时间的差，但是这里只考虑了自然日，没有考虑交易日
    m=int(len(df)/8-1)
    delta0=list()
    for i in range(m):
        s=8*(i+1)-1
        t=8*(i+2)-1
        delta=(df.index[t]-df.index[s]).days
        delta0.append(delta)
    return delta0
delta=tc0(df)#len(a)是有多少个交易日-1，sun(a)是一共的天数，具体的看开始的日期
def tc1(df,d,delta):
    c=0
    s=0
    for i0 in range(d):
        if s>=d:#这里只要满足了能够大于等于就结束了
            break 
        else:
            c=i0#这里的c表示不考虑的delta，再前一个可以考虑
            print(c+1)
            s=s+delta[-i0-1]
            #continue
    #那么我们可以计算的日期，从第一天起，到倒数第i0天，都是可以计算出当天的实际收益的
    m=len(delta)-c
    TR=[]
    for i1 in range(m):
        qh=0
        for s in range(d):
            qh=qh+delta[i1+s]
            if qh<d :            
                continue
            elif qh==d:
                Treal=d#c表示最后的持有期等于期限
                break
            elif qh>d:
                Treal=qh#如果出现qh>d也就是最后持有天数会大于期限，这里记录实际持有期
                break
        TR.append(Treal)#这里将每个交易日的实际持有的到期时间都计算出来了
    return TR,c
TR1,c1=tc1(df,d,delta)
#上面就完成了对于数据的时间的结果，接下来要讲对应的时间中的收益转化为正确的收益。
#=======================================================================

def tc2(df,d,delta):
    if d>3:
        c=0
        s=0
        for i0 in range(d):
            if s>=d:#这里只要满足了能够大于等于就结束了
                break 
            else:
                c=i0
                print(c+1)
                s=s+delta[-i0-1]
                #continue
            #那么我们可以计算的日期，从第一天起，到倒数第i0天，都是可以计算出当天的实际收益的
        m=len(delta)-c
        TR=[]
        for i1 in range(m):
            qh=0
            for s in range(d):
                qh=qh+delta[i1+s]
                if qh<d :            
                    continue
                elif qh==d:
                    Treal=d#c表示最后的持有期等于期限
                    break
                elif qh>d:
                    Treal=qh#如果出现qh>d也就是最后持有天数会大于期限，这里记录实际持有期
                    break
            TR.append(Treal)#这里将每个交易日的实际持有的到期时间都计算出来了
    elif d<=3:
        c=d
        m=len(delta)-d+1
        TR=[]
        for i in range(m):
            qh=0
            for s in range(d):
                qh=qh+delta[i+s]
            TR.append(qh)
        
    return TR,c
#这里已经准确的得到了每一个交易日实际的期限
TR,c=tc2(df,d,delta)
print(len(TR))



#=================================================================
#接下来需要对于这里的数据处理，使得他们真实的日收益率：
#最后实际可以用的数据实际是len(TR)天
#df1=df.drop("code",axis=1)#删除里面的string，方便除法
df2=df.iloc[:len(TR)*8,:]#这里需要删除最后几个，保留len(TR)*8个数据
#首先构造一个8*TR的list
a=[]
TR=TR1#如果这里的使用的是自然日，那么就直接换成TR1就可以了
for i in range(len(TR)):
    for s in range(8):
        a.append(d/TR[i])
df2["code"]=a
df22=df2
#print(len(a))    

df2["open"]=(df2["code"]*df2["open"]).values
df2["close"]=(df2["code"]*df2["close"]).values
df2["high"]=(df2["code"]*df2["high"]).values    
df2["low"]=(df2["code"]*df2["low"]).values    
df222=df2
#这里已经获得了我们想要的结果，也就是数据    
#%%
plt.plot(df2["high"])
#plt.plot(df2["low"])
#%%
#剔除收盘前的影响：
for i in range(int(len(df2)/8)):
    t=8*(i+1)-1
    df3=df2.drop(df2.index[t])
plt.plot(df3["high"])
    
    
    
    
    
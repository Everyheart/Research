# -*- coding: utf-8 -*-
"""
Created on Sat Nov 11 10:17:22 2017
研究问题一
变量数据搜集代码
@author: Everyheart
"""

#将要搜集数据的变量有：
#（1）时间T后的有关价格信息，





#变量信息汇总：
#（1）start：起始时间
#（2）TF：时间周期，也就是向后的时间的参数，TF的格式是'2016-01-01'
#（3）RD:被解释变量的数据的集合
#(4)stock='600000'这个是股票的代码
#(5)TM='30min'这个是用几分钟的数据去处理,，分别为1min/5min/15min/30min/60min，D(日)/W(周)/M(月)/Q(季)/Y(年)
#(6)TE:探寻周期结束的时间，一般我们设置为一周，也就是十天后左右，但是这里会由节假日的问题，最长节假日有7天，因此我们选择TF后的20天，这里能够处理
#(7)df1:是最近5个交易日数据的df
#(8)tf：具体的时间的选择，就是TF为起始后的多久时间作为我们研究的结果时间戳,具体是4表示4个半小时，最多可以研究80个


#函数信息汇总：
#(1)shiqu:对于时间进行处理
#(2)zdz: """返还五个内容，最高价格，最低价格，振幅,最高的涨幅，最大的跌幅，也就是五个变量的含义"""

#%%代码实现：


#（1）准备
import tushare as ts
import pandas as pd
from datetime import datetime
cons = ts.get_apis()
stock='000932'
TM='30min'
tf=4
Y,M,D=2017,11,10#定义时间
#（2）对于被解释变量的数据的整理
#1.我们需要在这里编写一个函数来对时间区间进行构建
def shiqu(Y,M,D):
    start=datetime(Y,M,D)
    delta=datetime(2017,1,21)-datetime(2017,1,1)
    result2=start+delta
    result1=start.strftime('%Y-%m-%d')
    result2=result2.strftime('%Y-%m-%d')
    return result1,result2
#获得具体的时间戳，这里是需要设置的
TF,TE=shiqu(Y,M,D)
#2.具体的数据的获取，从TF后的20天的都有，但是我们主要是需要前5个交易日的
df = ts.bar(stock, conn=cons, freq=TM, start_date=TF, end_date=TE)
df1=df.iloc[-40:,:]

#3.通过数据，提取出符合的数据，包括TF时间点的价格，tf时间点的
#具体的数据有：
#####(1)startprice:初始时刻价格
####（2）endprice:结束时刻的价格（3）zdf:最大的涨跌幅，这个就是最后的数据
startprice=df1.iloc[-1].loc['open']
endprice=df1.iloc[-tf].loc['close']
#对于最高涨幅和最大跌幅和振幅我们可以通过一个函数来定义出来
def zdz(df,tf,startprice):
    """返还五个内容，最高价格，最低价格，振幅,最高的涨幅，最大的跌幅，也就是五个变量的含义"""
    maxprice,minprice=df.iloc[-1].loc['high'],df.iloc[-1].loc['low']
    for i in range(tf):
        maxprice=max(maxprice,df.iloc[-i].loc['high'])
        minprice=min(minprice,df.iloc[-i].loc['low'])
    zhenfu=maxprice-minprice
    maxzf=(maxprice-startprice)/startprice
    maxdf=(minprice-startprice)/startprice
    return maxprice,minprice,zhenfu,maxzf,maxdf     
maxprice,minprice,zhenfu,maxzf,maxdf=zdz(df1,tf,startprice)
zdf=(endprice-startprice)/startprice#tf内的涨跌幅
A=[maxprice,minprice,zhenfu,maxzf,maxdf,zdf]#被解释变量汇总


#(3)对于解释变量进行数据的处理
#变量1：缠论的虚拟变量，以后来解决

#变量2：过去周期t的涨幅等变量：
    #从Y-M-D前n个交易日的数据提取
    #有关参数的定义
TM2='30min' #这里可以进行调整，选择日或者30分钟的数据
tf2=8 #向前提取多少个30分钟的数据进行处理
def shiqu2(Y,M,D):
    """返回的几个变量：分别是向开始的时间、结束的时间、和日线均线分类的开始的时间"""
    start=datetime(Y,M,D)
    delta=datetime(2017,1,21)-datetime(2017,1,1)
    delta2=datetime(2017,1,1)-datetime(2016,7,1)
    tfjx0=start-delta2
    tfjx=tfjx0.strftime('%Y-%m-%d')
    result2=start-delta
    result3=start.strftime('%Y-%m-%d')
    result1=result2.strftime('%Y-%m-%d')
    return result1,result3,tfjx
TF,TE,tfjx=shiqu2(Y,M,D)
df = ts.bar(stock, conn=cons, freq=TM2, start_date=TF, end_date=TE)
df1=df.iloc[-40:,:]
startprice=df1.iloc[tf2-1].loc['open']
endprice=df1.iloc[0].loc['close']
#获得开始和结束价格后计算出涨幅的变化
zdf2=(endprice-startprice)/startprice#我们获得的最后的涨跌幅

#变量3：日均线的分类：
dfjx = ts.bar(stock, conn=cons, start_date=tfjx, end_date=TE, ma=[5, 13, 21,34,55], factors=['vr', 'tor'])
dfjx.head(5)
def junxianleixin(df):
    """这里构建了两个虚拟变量，分别是：duibi这个是对比5和55日均线之间的关系，
    结果是0,1，duibi2是对比13和55日均线"""
    ma5=float(df.iloc[0].loc['ma5'])
    ma13=float(df.iloc[0].loc['ma13'])
    ma55=float(df.iloc[0].loc['ma55'])
    if ma5>ma55:
        duibi=0
    else:
            duibi=1
    if ma13>ma55:
        duibi2=0
    else:
            duibi2=1
    return duibi,duibi2
junxianleixin1,junxianleixin2=junxianleixin(dfjx)

#变量4：交易角度的趋势的分析
    #设定有关参数,这里只能准确的设计出最近一天的买卖比
    #dfjx = ts.tick(stock, conn=cons, date=jiaoyi)这里的数据并不容易获得
def shiqu3(Y,M,D):
    start=datetime(Y,M,D)
    delta3=datetime(2017,1,2)-datetime(2017,1,1)
    result=[]
    jg=start
    for i in range(20):
        jg=jg-delta3
        jg1=jg.strftime('%Y-%m-%d')
        result.append(jg1)
    return result
result=shiqu3(Y,M,D)
    #这里因为这里的数据存在问题，因此我们必须要进行循环尝试，来获得最前一个交易日的数据
i=0
while i <20:
    try:
        dfjx = ts.tick(stock, conn=cons, date=result[i])
        a=type(dfjx)
        if a==pd.core.frame.DataFrame:
           break
    except:
        i=i+1
        continue
    #接下来对于这里的数据进行一个简单的处理，来获得买卖比，通过一个函数来获得
def sellbuy(df):
    sellall=0
    buyall=0
    m=df.shape[0]
    for i in range(m):
        if df.iloc[i].loc['type']==1:
            sellall=sellall+df.iloc[i].loc['vol']
        elif df.iloc[i].loc['type']==0:
            buyall=buyall+df.iloc[i].loc['vol']
    bizhi=buyall/sellall
    return bizhi,sellall,buyall
sbbz,sellall,buyall=sellbuy(dfjx)
#变量5：对于基本面信息的判断



#总结：所有的变量有：
#被解释变量：A=[maxprice,minprice,zhenfu,maxzf,maxdf,zdf]#被解释变量汇总
#解释变量：zdf2（涨跌幅）junxianleixin1,junxianleixin2（这是中期短期均线分类的结果）
## 解释变量：bizhi,sellall,buyall，sbbz,sellall,buyall=sellbuy(dfjx)这些是交易角度的分析变量

#%%
#（3）第三部分：统计上的检验
#1.简单的一元线性回归的拟合
import statsmodels.api as sm
model=sm.OLS(maxzf,sm.add_constant(zdf2)).fit()
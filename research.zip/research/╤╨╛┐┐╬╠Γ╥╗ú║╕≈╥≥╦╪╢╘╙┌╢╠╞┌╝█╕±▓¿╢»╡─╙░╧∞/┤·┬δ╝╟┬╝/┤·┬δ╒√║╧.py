# -*- coding: utf-8 -*-
"""
Created on Tue Nov 21 08:40:28 2017

@author: Everyheart
"""
#%%
from datetime import datetime
import pandas as pd
import tushare as ts
#对于解释变量和被解释变量进行整体的定义函数，这样才能够获得想要的数据
def shengcheng(stock='600000',TM="30min",tf=4,TM2='30min',tf2=8,Y=2017,M=11,D=1,zhihou=30):
    def shiqu0(Y,M,D,zhihou,stock):
        cons = ts.get_apis()
        timetable=list()
        result=datetime(Y,M,D)
        delta=datetime(2017,1,2)-datetime(2017,1,1)
        for i in range(zhihou):
            result=result-delta
            result1=result.strftime('%Y-%m-%d')
            try:
                dfjx = ts.tick(stock, conn=cons, date=result1)
                a=type(dfjx)
                if  a==pd.core.frame.DataFrame:
                    timetable.append(result)
            except:
                    continue
        return timetable
    a=shiqu0(Y,M,D,zhihou,stock)
    def dealdata(Y,M,D,stock,tf,TM,TM2,tf2,cons = ts.get_apis()):

        def shiqu(Y,M,D):
            start=datetime(Y,M,D)
            delta=datetime(2017,1,21)-datetime(2017,1,1)
            result2=start+delta
            result1=start.strftime('%Y-%m-%d')
            result2=result2.strftime('%Y-%m-%d')
            return result1,result2
        TF,TE=shiqu(Y,M,D)
        cons = ts.get_apis()
        df = ts.bar(stock, conn=cons, freq=TM, start_date=TF, end_date=TE)
        df1=df.iloc[-40:,:]
        startprice=df1.iloc[-1].loc['open']
        endprice=df1.iloc[-tf].loc['close']
        def zdz(df,tf,startprice):
            """返还五个内容，最高价格，最低价格，振幅,最高的涨幅，最大的跌幅，也就是五个变量的含义"""
            maxprice,minprice=df.iloc[-1].loc['high'],df.iloc[-1].loc['low']
            for i in range(tf):
                maxprice=max(maxprice,df.iloc[-i].loc['high'])
                minprice=min(minprice,df.iloc[-i].loc['low'])
            zhenfu=maxprice-minprice
            maxzf=(maxprice-startprice)/startprice
            maxdf=(minprice-startprice)/startprice
            return maxprice,minprice,zhenfu,maxzf,maxdf    
        maxprice,minprice,zhenfu,maxzf,maxdf=zdz(df1,tf,startprice)
        zdf=(endprice-startprice)/startprice
        A=[maxprice,minprice,zhenfu,maxzf,maxdf,zdf]#被解释变量汇总

        #=======================================
        def shiqu2(Y,M,D):
            """返回的几个变量：分别是向开始的时间、结束的时间、和日线均线分类的开始的时间"""
            start=datetime(Y,M,D)
            delta=datetime(2017,1,21)-datetime(2017,1,1)
            delta2=datetime(2017,1,1)-datetime(2016,7,1)
            tfjx0=start-delta2
            tfjx=tfjx0.strftime('%Y-%m-%d')
            result2=start-delta
            result3=start.strftime('%Y-%m-%d')
            result1=result2.strftime('%Y-%m-%d')
            return result1,result3,tfjx
        TF,TE,tfjx=shiqu2(Y,M,D)
        df = ts.bar(stock, conn=cons, freq=TM2, start_date=TF, end_date=TE)
        df1=df.iloc[-40:,:]
        startprice=df1.iloc[tf2-1].loc['open']
        endprice=df1.iloc[0].loc['close']
        zdf2=(endprice-startprice)/startprice#我们获得的最后的涨跌幅
        #=========================================================
        dfjx = ts.bar(stock, conn=cons, start_date=tfjx, end_date=TE, ma=[5, 13, 21,34,55], factors=['vr', 'tor'])
        def junxianleixin(df):
            """这里构建了两个虚拟变量，分别是：duibi这个是对比5和55日均线之间的关系，
            结果是0,1，duibi2是对比13和55日均线"""
            ma5=float(df.iloc[0].loc['ma5'])
            ma13=float(df.iloc[0].loc['ma13'])
            ma55=float(df.iloc[0].loc['ma55'])
            if ma5>ma55:
                duibi=0
            else:
                    duibi=1
            if ma13>ma55:
                duibi2=0
            else:
                duibi2=1
            return duibi,duibi2
        junxianleixin1,junxianleixin2=junxianleixin(dfjx)
        #===========================
        def shiqu3(Y,M,D):
            start=datetime(Y,M,D)
            delta3=datetime(2017,1,2)-datetime(2017,1,1)
            result=[]
            jg=start
            for i in range(20):
                jg=jg-delta3
                jg1=jg.strftime('%Y-%m-%d')
                result.append(jg1)
            return result
        result=shiqu3(Y,M,D)
        i=0
        while i <20:
            try:
                dfjx = ts.tick(stock, conn=cons, date=result[i])
                a=type(dfjx)
                if a==pd.core.frame.DataFrame:
                    break
            except:
                    i=i+1
                    continue    
        def sellbuy(df):
            sellall=0
            buyall=0
            m=df.shape[0]
            for i in range(m):
                if df.iloc[i].loc['type']==1:
                    sellall=sellall+df.iloc[i].loc['vol']
                elif df.iloc[i].loc['type']==0:
                    buyall=buyall+df.iloc[i].loc['vol']
            bizhi=buyall/sellall
            return bizhi,sellall,buyall
        sbbz,sellall,buyall=sellbuy(dfjx)        
        dataall=[maxprice,minprice,zhenfu,maxzf,maxdf,zdf,zdf2,junxianleixin1,junxianleixin2,sbbz,sellall,buyall]
        return dataall
        
    for i in range(len(a)):
        data=[]
        Y,M,D=a[i].year,a[i].month,a[i].day
        dataset=dealdata(Y,M,D,stock,tf,tf2,TM,TM2)
        data=data.append(dataset)
ss=shengcheng(stock='000932',TM="30min",tf=4,TM2='30min',tf2=8,Y=2017,M=11,D=1,zhihou=30)
